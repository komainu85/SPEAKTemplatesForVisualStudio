﻿define(["sitecore"], function (Sitecore) {
    var $safeprojectname$ = Sitecore.Definitions.App.extend({

        filesUploaded: [],

        initialized: function () { },

        initialize: function () {
            
        },

    });

    return $safeprojectname$;
});